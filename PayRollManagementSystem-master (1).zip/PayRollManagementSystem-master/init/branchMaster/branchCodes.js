const branch_codes = [
    {
      code: 1,
      name: "Head Office - Karad"
    },
    {
      code: 2,
      name: "Branch Office - Kolhapur"
    },
    {
      code: 3,
      name: "Branch Office - Pune"
    },
    {
      code: 4,
      name: "Branch Office - Sangli"
    },
    {
      code: 5,
      name: "Branch Office - Satara"
     }
  ]
  module.exports = branch_codes;