const cast_codes =[
    {
        code:1,
        name:"Maratha"
    },
    {
        code:2,
        name:"Lingayat"
    },
    {
        code:3,
        name:"Muslim"
    },
    {
        code:4,
        name:"SC"
    },
    {
        code:5,
        name:"NT"
    },
    {
        code:6,
        name:"Others"
    }

]

module.exports = cast_codes;