const section_codes = [
    {
      code: 1,
      name: "Finance - Accounts"
    },
    {
      code: 2,
      name: "Human Resources - HR"
    },
    {
      code: 3,
      name: "Marketing - Sales"
    },
    {
      code: 4,
      name: "Operations"
    },
    {
      code: 5,
      name: "IT - Technology"
     }
  ]
  module.exports = section_codes;