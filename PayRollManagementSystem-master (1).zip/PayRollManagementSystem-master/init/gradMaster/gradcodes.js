const grade_codes = [
  {
    code: 1,
    name: "Clerk"
  },
  {
    code: 2,
    name: "Loan Officer"
  },
  {
    code: 3,
    name: "Bank Officer"
  },
  {
    code: 4,
    name: "Bank Manager"
  },
  {
    code: 5,
    name: "Cashier"
  }
]
  module.exports = grade_codes;